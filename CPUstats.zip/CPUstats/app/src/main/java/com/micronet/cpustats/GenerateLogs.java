package com.micronet.cpustats;

import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

/**
 * Created by eemaan.siddiqi on 12/20/2016.
 */

public class GenerateLogs {

    public static final String TAG = "GenerateLogs";
    //Declaring the Directory
    public static File logDir;
    public static BufferedWriter bufferedWriter = null;
    public static FileWriter fileWriter = null;
    public static String logHeader = "TimeStamp, Process/Package, Percentage, Additional Notes,";

    //Log the test activity
    public static void LogCsvToFile(ProcessInfo processInfo, String addtionalNotes) {

        boolean fileExists;

        String fileName = "CPUStats.csv";

        String columnSep = ",";

        File file = new File(logDir, fileName);
        fileExists = file.exists();
//        if (!file.exists()) {
//            fileExists = false;
//            Log.d(TAG, "CPUStats.csv: File Doesn't exist");
//            try {
//                file.createNewFile();
//
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }

        try {
            fileWriter = new FileWriter(file.getAbsoluteFile(), true);
            bufferedWriter = new BufferedWriter(fileWriter);
            if (!fileExists) {
                bufferedWriter.write("TimeStamp,Process/Package,CPU Percentage,Resident Set Size,Virtual Set Size,Additional Notes,");
                bufferedWriter.newLine();
                //bufferedWriter.write(logHeader);
            }
            bufferedWriter.write(Utils.formatDate(System.currentTimeMillis()) + columnSep);
            bufferedWriter.write(processInfo.getName() + columnSep);
            bufferedWriter.write(processInfo.getCpuPercent() + columnSep);
            bufferedWriter.write(processInfo.getResidentSetSize() + columnSep);
            bufferedWriter.write(processInfo.getVirtualSetSize()  + columnSep);
            bufferedWriter.write(addtionalNotes + " " + columnSep);
            bufferedWriter.newLine();
        } catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
            e.printStackTrace();
        } finally {
            try {
                if (bufferedWriter != null)
                    bufferedWriter.close();
                if (fileWriter != null)
                    fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}