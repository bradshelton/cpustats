package com.micronet.cpustats;

import android.util.Log;

public class ProcessInfo {
    private static final String TAG = "ProcessInfo";

    private String cpuPercent;
    private String residentSetSize;
    private String virtualSetSize;
    private String name;

    public ProcessInfo(String line) {
        String[] parts = line.trim().split("\\s+");
        name = parts[9];
        cpuPercent = parts[2];
        Log.d(TAG, String.format("%s CPU percentage: %s", name, cpuPercent));
        virtualSetSize = parts[5];
        Log.d(TAG, String.format("%s virtual set size: %s", name, virtualSetSize));
        residentSetSize = parts[6];
        Log.d(TAG, String.format("%s resident set size: %s", name, virtualSetSize));
    }

    public String getCpuPercent() {
        return cpuPercent;
    }

    public String getResidentSetSize() {
        return residentSetSize;
    }

    public String getName() {
        return name;
    }

    public String getVirtualSetSize() {
        return virtualSetSize;
    }
}
