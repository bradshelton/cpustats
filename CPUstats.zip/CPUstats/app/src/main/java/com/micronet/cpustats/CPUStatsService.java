package com.micronet.cpustats;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.util.HashMap;

public class CPUStatsService extends Service {

    private static String TAG = "CPUStatsService-Service";

    private Handler cpuStatHandler;
    private final long TIME_TEN_SEC =0;
    private final long TIME_INTERVAL = TIME_TEN_SEC; //default
    private static final String JUNGO_PACKAGE ="com.jungo.vudrive";
    private static final String INTHINC_API_PACKAGE ="com.inthinc.inthincapi";
    private static final String INTHINC_CONTROL_PACKAGE ="com.inthinc.inthinccontrol";
    private static final String INTHINC_VEHICLE_PACKAGE ="com.inthinc.inthincvehicle";
    private static final String LIGHTMETRICS_RIDECAM_PACKAGE ="lm.micronet.ridecamandroidapp";



    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {

        // App initialization
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            String version = pInfo.versionName;
            Log.d(TAG, String.format("CpuStats v%s started.", version));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        //Log Dir Initialization
        //Creating a Directory if it isn't available
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            File Root = Environment.getExternalStorageDirectory(); //Creating File Storage
            GenerateLogs.logDir = new File(Root.getAbsolutePath() + "/MicronetService");
            if (!GenerateLogs.logDir.exists()) {
                GenerateLogs.logDir.mkdir();
            }
        }

        if(cpuStatHandler == null){
            cpuStatHandler = new Handler((Looper.myLooper()));
            cpuStatHandler.post(getCpuUsage);
        }
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG,"STOP");
        cpuStatHandler.removeCallbacks(getCpuUsage);
        Toast.makeText(this,"Service Stopped",Toast.LENGTH_LONG).show();
    }


    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
    }

    final Runnable getCpuUsage = new Runnable(){
        @Override
        public void run() {

            try {
                String[] packages = {JUNGO_PACKAGE, INTHINC_API_PACKAGE, INTHINC_CONTROL_PACKAGE, INTHINC_VEHICLE_PACKAGE, LIGHTMETRICS_RIDECAM_PACKAGE};
                logAppStats(packages);
                Log.d(TAG, "Handler: Delayed by " + TIME_INTERVAL + " seconds");
                cpuStatHandler.postDelayed(this, TIME_INTERVAL);
            }
            catch (Exception e)
            {
                e.printStackTrace();
                Log.d(TAG, "run: bh");
            }
        }

        private void logAppStats(String[] packageNames) {
            HashMap<String, ProcessInfo> processes = Utils.getProcessInformation(packageNames);
            for (String packageName : processes.keySet()) {
                ProcessInfo processInfo = processes.get(packageName);
                Log.d(TAG, processInfo + " CPU usage: " + processes.get(packageName).getCpuPercent());
                Log.d(TAG, processInfo + " Resident set size: " + processes.get(packageName).getResidentSetSize());
                Log.d(TAG, processInfo + " Virtual set size: " + processes.get(packageName).getVirtualSetSize());
                GenerateLogs.LogCsvToFile(processInfo, "none");
            }
        }
    };



}
