package com.micronet.cpustats;

import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import static android.content.Context.ACTIVITY_SERVICE;

public class Utils {

    public static String formatDate(Date date) {
        return new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(date);
    }

    public static String formatDateShort(Date date) {
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    public static String formatDateShort(long time) {
        return formatDateShort(new Date(time));
    }

    public static String formatDate(long time) {
        return formatDate(new Date(time));
    }

    public static HashMap<String, ProcessInfo> getProcessInformation(String[] packages) { //for multiple processes
        HashMap<String, ProcessInfo> processes = new HashMap<>();
        try {
            String[] cmd = {"top", "-n", "1"};
            Process process = Runtime.getRuntime().exec(cmd);
            BufferedReader stdInput = new BufferedReader(new
                    InputStreamReader(process.getInputStream()));

            BufferedReader stdError = new BufferedReader(new
                    InputStreamReader(process.getErrorStream()));

            // read the output from the command
            System.out.println("Here is the standard output of the command:\n");
            System.out.println("" +stdInput);
            String s = null;
            while ((s = stdInput.readLine()) != null) {
                for(int i = 0; i < packages.length; i++) {
                    if(s.contains(packages[i])) {
                        processes.put(packages[i], new ProcessInfo(s));
                    }
                }
            }

            // read any errors from the attempted command
            System.out.println("Here is the standard error of the command (if any):\n");
            while ((s = stdError.readLine()) != null) {
                System.out.println(s);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return processes;
    }

     public static void  logappstats(Context context) {

         ActivityManager mgr = (ActivityManager)context.getSystemService(ACTIVITY_SERVICE);
         List<ActivityManager.RunningAppProcessInfo> processes = mgr.getRunningAppProcesses();
         Log.e("DEBUG", "Running processes:");
         for(Iterator i = processes.iterator(); i.hasNext(); )
         {
             ActivityManager.RunningAppProcessInfo p = (ActivityManager.RunningAppProcessInfo)i.next();
             Log.e("DEBUG", "  process name: "+p.processName);
             Log.e("DEBUG", "     pid: "+p.pid);
             int[] pids = new int[1];
             pids[0] = p.pid;
             android.os.Debug.MemoryInfo[] MI = mgr.getProcessMemoryInfo(pids);
             Log.e("memory","     dalvik private: " + MI[0].dalvikPrivateDirty);
             Log.e("memory","     dalvik shared: " + MI[0].dalvikSharedDirty);
             Log.e("memory","     dalvik pss: " + MI[0].dalvikPss);
             Log.e("memory","     native private: " + MI[0].nativePrivateDirty);
             Log.e("memory","     native shared: " + MI[0].nativeSharedDirty);
             Log.e("memory","     native pss: " + MI[0].nativePss);
             Log.e("memory","     other private: " + MI[0].otherPrivateDirty);
             Log.e("memory","     other shared: " + MI[0].otherSharedDirty);
             Log.e("memory","     other pss: " + MI[0].otherPss);

             Log.e("memory","     total private dirty memory (KB): " + MI[0].getTotalPrivateDirty());
             Log.e("memory","     total shared (KB): " + MI[0].getTotalSharedDirty());
             Log.e("memory","     total pss: " + MI[0].getTotalPss());
         }

        ActivityManager mngr = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);

        int showLimit = 0;
        List<ActivityManager.RunningTaskInfo> allTasks = mngr.getRunningTasks(showLimit);
       // Loop through all tasks returned.
        for (ActivityManager.RunningTaskInfo aTask : allTasks) {
            Log.i("CPUStatsService", "Task: " + aTask.baseActivity.getClassName());
        }
    }

    private float readCpuUsage(int pid) {
        try {
            RandomAccessFile reader = new RandomAccessFile("/proc/" + pid + "/stat", "r");
            String load = reader.readLine();

            String[] toks = load.split(" ");

            long idle1 = Long.parseLong(toks[5]);
            long cpu1 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[4])
                    + Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);

            try {
                Thread.sleep(360);
            } catch (Exception e) {}

            reader.seek(0);
            load = reader.readLine();
            reader.close();

            toks = load.split(" ");

            long idle2 = Long.parseLong(toks[5]);
            long cpu2 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[4])
                    + Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);

            return (float)(cpu2 - cpu1) / ((cpu2 + idle2) - (cpu1 + idle1));

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return 0;}


}
